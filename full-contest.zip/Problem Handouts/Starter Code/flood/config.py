from bots.basic import BasicBot

bot = BasicBot  # Bot to test
difficulty = 0  # 0 is easy, 1 is medium, 2 is hard
seed = 1  # Random seed

# Format message for visualization
def format_message(x: int) -> str:
    return str(x)

# Archipelago CLI Tool

## Directory Structure
```
archipelago/
├── cli.py                    # Command-Line Interface for testing & visualization
├── engine.py                 # Core grading and execution engine
├── visualizer.py             # Pygame-based step-through visualizer
├── visualizer.html           # Web-based visualizer (preferred)
├── tests/                    # Per-task public tests
│   ├── task1.json
│   ├── task2.json
│   └── …
├── tasks/                    # Your per-task programs
│   ├── task1.csv
│   ├── task2.csv
│   └── …
├── aggregate_tasks.py        # Bundles all tasks into submission.json
└── requirements.txt          # Python dependencies
```

## Installation

1. Create a virtual environment (optional but recommended):
   ```bash
   python3.12 -m venv venv
   source venv/bin/activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### Run Local Tests
Use the CLI tool to run your program against the provided test cases.

```bash
python cli.py -c tasks/task1.csv -t tests/task1.json
```

**Optional flags:**
- `-d, --debug`     : Enable detailed debugging output.
- `-v, --verbose`   : Verbose per-test reporting.
- `-z, --visualize` : Launch the Pygame visualizer on the first test.

**Example with all flags:**
```bash
python cli.py \
  -c your_program.csv \
  -t test_cases.json \
  --debug --verbose --visualize
```

### Visualize Execution
The recommended way to visualize execution is by opening `visualizer.html` directly in your browser.

Alternatively, running the CLI with `--visualize` will launch the Pygame visualizer. Use the **←/→** keys to step backward/forward, **Esc** to quit.

## Output
After tests finish, you’ll see:
```
Passed X out of Y cases.
```
The process exits with status `0` if **all** tests pass, otherwise non‑zero.

## Submission Guidelines
For tasks 1-9:
1. **Implement each task** as `task1.csv`, `task2.csv`, … up to `task9.csv` and place them in the `tasks/` folder.

2. **Bundle everything** by running:
   ```bash
   python aggregate_tasks.py
   ```
   This will produce `submission.json` in the project root.

3. **Submit only** `submission.json`.  
   _Do not_ modify any of the provided `.py` files. Simply add your programs to the `tasks/` folder and run the aggregation script.
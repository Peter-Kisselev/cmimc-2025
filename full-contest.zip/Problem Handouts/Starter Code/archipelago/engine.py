from typing import List, Tuple, Optional, Dict, Any
import csv
import json

MAX_STEPS = 1000000
DIRS = [(-1, 0), (1, 0), (0, -1), (0, 1)]
ops = ['#','-','i','d','a','s','p','o','j','f','j<','j=','j>','f<','f=','f>']
ops_opp = ['p','j','f','j<','j=','j>','f<','f=','f>']

class ArchipelagoResult:
    def __init__(self, test_path: str, num_tests: int, num_pass_tests: int, num_islands: int):
        self.test_path = test_path
        self.num_tests = num_tests
        self.num_pass_tests = num_pass_tests
        self.num_islands = num_islands

class ArchipelagoSimulator:
    def __init__(self, code: List[List[str]], islands: List[List[int]], num_islands: int, debug: bool = False):
        self.code = code
        self.islands = islands
        self.num_islands = num_islands
        self.debug = debug

        self.H = len(self.code)
        self.W = len(self.code[0])

        self.reset()

    def reset(self) -> None:
        self.pos = (1, 1) # Position of IP
        self.direc = (1, 0) # Direction of IP
        self.left_hand = True # Is IP on left hand?

        self.stacks = [[] for _ in range(self.num_islands)] # Island stacks

        self._step = 0

    def fill_stack(self, island_index: int, mn: int) -> None:
        while len(self.stacks[island_index]) < mn:
            self.stacks[island_index].append(0)

    def apply_stack(self, island_index: int, f: Any) -> None:
        self.stacks[island_index][-1] = f(self.stacks[island_index][-1])

    def add(self, pos: Tuple[int, int], *deltas: Tuple[int, int]) -> Tuple[int, int]:
        x, y = pos
        dx = sum(d[0] for d in deltas)
        dy = sum(d[1] for d in deltas)
        return (x + dx, y + dy)

    def rotate(self, flip: bool = False) -> Tuple[int, int]:
        if self.left_hand ^ flip:
            return (-self.direc[1], self.direc[0])
        else:
            return (self.direc[1], -self.direc[0])

    def flip(self, direc: Tuple[int, int]) -> Tuple[int, int]:
        return (-direc[0], -direc[1])

    def move(self) -> None:
        next_pos = self.add(self.pos, self.direc)
        if self.islands[next_pos[0]][next_pos[1]] == -1:
            self.direc = self.rotate()
        else:
            next_pos = self.add(self.pos, self.direc, self.rotate(flip=True))
            if self.islands[next_pos[0]][next_pos[1]] >= 0:
                self.direc = self.rotate(flip=True)
                self.pos = next_pos
            else:
                self.pos = self.add(self.pos, self.direc)

    def pop_stack(self, island_index: int) -> int:
        return self.stacks[island_index].pop()

    def push_stack(self, island_index: int, x: int) -> None:
        self.stacks[island_index].append(x)

    def get_stack(self, island_index: int) -> int:
        if len(self.stacks[island_index]):
            return self.stacks[island_index][-1]
        return 0

    def opposite(self) -> Tuple[int, int]:
        norm_direc = self.rotate(flip=True)

        pos = self.pos
        pos = self.add(pos, norm_direc)

        while self.islands[pos[0]][pos[1]] == -1:
            pos = self.add(pos, norm_direc)
            if pos[0] < 0 or pos[0] >= self.H or pos[1] < 0 or pos[1] >= self.W:
                raise RuntimeError("No opposite island found.")
        return pos

    def step(self) -> Optional[List[int]]:
        if self._step >= MAX_STEPS:
            return None
        self._step += 1

        op = self.code[self.pos[0]][self.pos[1]]
        island_index = self.islands[self.pos[0]][self.pos[1]]

        if self.debug:
            print(f"step {self._step}, coordinate {self.pos}, direc {self.direc}, left_hand {self.left_hand}")

        if self.pos[0] == self.H - 2 and self.pos[1] == self.W - 2:
            return self.stacks[1] # Output stack

        if op == '' or island_index == -1:
            raise RuntimeError("Program error, IP on water.")
        elif op == '#' or op == '-':
            self.move()
        elif op == 'i':
            self.fill_stack(island_index, 1)
            self.apply_stack(island_index, lambda z: z + 1)
            self.move()
        elif op == 'd':
            self.fill_stack(island_index, 1)
            self.apply_stack(island_index, lambda z: z - 1)
            self.move()
        elif op == 'a':
            self.fill_stack(island_index, 2)
            x = self.pop_stack(island_index)
            y = self.pop_stack(island_index)
            self.push_stack(island_index, x + y)
            self.move()
        elif op == 's':
            self.fill_stack(island_index, 1)
            x = self.pop_stack(island_index)
            self.fill_stack(island_index, 1)
            y = self.pop_stack(island_index)
            self.push_stack(island_index, y - x)
            self.move()
        elif op == 'o':
            self.fill_stack(island_index, 1)
            self.pop_stack(island_index)
            self.move()
        elif op in ops_opp:
            opp_pos = self.opposite()
            opp_island_index = self.islands[opp_pos[0]][opp_pos[1]]
            if self.debug:
                print(f"opposite island position {opp_pos}, index {opp_island_index}")

            if op == 'p':
                self.fill_stack(island_index, 1)
                x = self.get_stack(island_index)
                self.push_stack(opp_island_index, x)
                self.move()
            else:
                conditional = False
                if (op == 'f') or (op == 'j'):
                    conditional = True
                else:
                    x = self.get_stack(island_index)
                    y = self.get_stack(opp_island_index)

                    if op[-1] == '<':
                        conditional = bool(x < y)
                    elif op[-1] == '=':
                        conditional = bool(x == y)
                    elif op[-1] == '>':
                        conditional = bool(x > y)
                    else:
                        raise ValueError(f"Invalid conditional operation {op} found.")

                if conditional:
                    self.pos = opp_pos
                    if op[0] == 'j':
                        self.left_hand = not self.left_hand
                    elif op[0] == 'f':
                        self.direc = self.flip(self.direc)
                else:
                    self.move()
        else:
            raise RuntimeError(f"Invalid operation {op} found.")

    def initialize(self, inp: List[int]) -> None:
        self.reset()
        self.stacks[0] = inp

    def simulate(self, inp: List[int]) -> Optional[List[int]]:
        self.initialize(inp)
        while self._step < MAX_STEPS:
            result = self.step()
            if result is not None:
                return result
        return None

class ArchipelagoEngine:
    @staticmethod
    def _parse_code(code_path: str) -> List[List[str]]:
        with open(code_path) as f:
            code = list(csv.reader(f))

        H = len(code)
        W = len(code[0])

        if H >= 512 or W >= 512:
            raise ValueError("Program size too large.")

        for i in range(H):
            row = code[i]
            if len(row) != W:
                raise ValueError("Inconsistent row length.")
            for j in range(W):
                if i == 0 or i == H - 1 or j == 0 or j == W - 1:
                    code[i][j] = ''
                if row[j] not in ops:
                    code[i][j] = ''

        if H < 4 or W < 4:
            raise ValueError("Program size too small.")

        return code

    @staticmethod
    def _initialize_islands(code: List[List[str]]) -> Tuple[List[List[int]], int]:
        H = len(code)
        W = len(code[0])

        if code[1][1] not in ops or code[H - 2][W - 2] not in ops:
            raise ValueError("Missing input or output island.")

        islands = [[-1] * W for _ in range(H)]
        num_islands = 0

        def traverse(i, j, num_islands):
            if islands[i][j] == -1 and code[i][j] in ops:
                islands[i][j] = num_islands

                q = [(i, j)]
                while len(q):
                    k, l = q.pop()
                    for dk, dl in DIRS:
                        nk, nl = k + dk, l + dl
                        if islands[nk][nl] == -1 and code[nk][nl] in ops:
                            islands[nk][nl] = num_islands
                            q.append((nk, nl))
                return num_islands + 1
            return num_islands

        num_islands = traverse(1, 1, num_islands)
        num_islands = traverse(H - 2, W - 2, num_islands)
        for i in range(1, H - 1):
            for j in range(1, W - 1):
                num_islands = traverse(i, j, num_islands)

        return islands, num_islands

    @staticmethod
    def _parse_tests(test_path: str) -> List[Dict[str, List[int]]]:
        with open(test_path) as f:
            return json.loads(f.read())

    def grade(self, code_path: str, test_path: str, debug: bool = False, verbose: bool = False) -> ArchipelagoResult:
        code = self._parse_code(code_path)
        islands, num_islands = self._initialize_islands(code)

        simulator = ArchipelagoSimulator(code, islands, num_islands, debug)

        tests = self._parse_tests(test_path)

        num_tests = len(tests)
        num_pass_tests = 0
        for test_case in tests:
            if verbose:
                print(f"Running test with input {test_case['input']}")
            
            output = simulator.simulate(test_case["input"])
            if output is None:
                if verbose:
                    print("Maximum steps exceeded")
            else:
                if output == test_case["output"]:
                    num_pass_tests += 1
                    if verbose:
                        print("Success")
                else:
                    if verbose:
                        print(f"Fail, gave {output} when expected is {test_case['output']}")

        return ArchipelagoResult(test_path, num_tests, num_pass_tests, num_islands)

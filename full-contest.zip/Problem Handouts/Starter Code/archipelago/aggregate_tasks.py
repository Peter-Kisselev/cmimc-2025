#!/usr/bin/env python3
import os
import json
import sys

def main():
    root = os.path.dirname(os.path.abspath(__file__))
    tasks_dir = os.path.join(root, "tasks")
    out_path = os.path.join(root, "submission.json")

    if not os.path.isdir(tasks_dir):
        print(f"Error: 'tasks/' directory not found at {tasks_dir}", file=sys.stderr)
        sys.exit(1)

    bundled = {}
    for i in range(1, 10):
        fname = f"task{i}.csv"
        full = os.path.join(tasks_dir, fname)
        if os.path.isfile(full):
            with open(full, "r", encoding="utf-8") as f:
                bundled[fname] = f.read().replace('\n', ';')
            print(f" + bundled {fname}")
        else:
            print(f" ! warning: {fname} not found", file=sys.stderr)

    with open(out_path, "w", encoding="utf-8") as out:
        json.dump(bundled, out, indent=2)
    print(f"\n✓ Created {os.path.basename(out_path)}")

if __name__ == "__main__":
    main()

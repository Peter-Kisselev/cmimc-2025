import pygame
import sys
import copy
from engine import ArchipelagoSimulator, ArchipelagoEngine, MAX_STEPS

CELL_SIZE = 30
LAND_COLOR = (255, 248, 220)
WATER_COLOR = (173, 216, 230)
OUTLINE_COLOR = (0, 0, 0)
ARROW_COLOR = (255, 0, 0)
FONT_SIZE = 18

class Visualizer:
    def __init__(self, code_path, inp):
        code = ArchipelagoEngine._parse_code(code_path)
        islands, num_islands = ArchipelagoEngine._initialize_islands(code)
        self.islands_map = islands
        self.num_islands = num_islands
        self.simulator = ArchipelagoSimulator(code, islands, num_islands, debug=False)
        self.history = []
        self._build_history(inp)
        self.code = code
        self.H = len(code)
        self.W = len(code[0])
        pygame.init()
        self.margin = max(80, (self.num_islands + 2) * (FONT_SIZE + 4))
        size = (self.W * CELL_SIZE, self.H * CELL_SIZE + self.margin)
        self.screen = pygame.display.set_mode(size)
        pygame.display.set_caption('Archipelago Visualizer')
        self.font = pygame.font.SysFont('Arial', FONT_SIZE)
        self.current_idx = 0

    def _build_history(self, inp):
        self.simulator.initialize(inp)
        self._record_state()
        while True:
            result = self.simulator.step()
            self._record_state()
            if result is not None or self.simulator._step >= MAX_STEPS:
                break

    def _record_state(self):
        st = {
            'pos': self.simulator.pos,
            'direc': self.simulator.direc,
            'step': self.simulator._step,
            'stacks': copy.deepcopy(self.simulator.stacks)
        }
        self.history.append(st)

    def run(self):
        clock = pygame.time.Clock()
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RIGHT:
                        self.current_idx = min(self.current_idx + 1, len(self.history)-1)
                    elif event.key == pygame.K_LEFT:
                        self.current_idx = max(self.current_idx - 1, 0)
                    elif event.key == pygame.K_ESCAPE:
                        running = False
            self.draw_frame(self.current_idx)
            pygame.display.flip()
            clock.tick(30)
        pygame.quit()
        sys.exit(0)

    def draw_frame(self, idx):
        self.screen.fill(WATER_COLOR)
        state = self.history[idx]
        for i in range(self.H):
            for j in range(self.W):
                rect = pygame.Rect(j*CELL_SIZE, i*CELL_SIZE, CELL_SIZE, CELL_SIZE)
                color = LAND_COLOR if self.code[i][j] else WATER_COLOR
                pygame.draw.rect(self.screen, color, rect)
                pygame.draw.rect(self.screen, OUTLINE_COLOR, rect, 1)
                island_idx = self.islands_map[i][j]
                if island_idx >= 0:
                    num_surf = self.font.render(str(island_idx), True, OUTLINE_COLOR)
                    num_rect = num_surf.get_rect(center=rect.center)
                    self.screen.blit(num_surf, num_rect)
        i, j = state['pos']
        cx = j*CELL_SIZE + CELL_SIZE//2
        cy = i*CELL_SIZE + CELL_SIZE//2
        di, dj = state['direc']
        hw = CELL_SIZE//2 - 4  # half width for arrow head
        if (di, dj) == (0, 1):  # right
            pts = [(cx+hw, cy), (cx-hw, cy-hw), (cx-hw, cy+hw)]
        elif (di, dj) == (0, -1):  # left
            pts = [(cx-hw, cy), (cx+hw, cy-hw), (cx+hw, cy+hw)]
        elif (di, dj) == (1, 0):  # down
            pts = [(cx, cy+hw), (cx-hw, cy-hw), (cx+hw, cy-hw)]
        elif (di, dj) == (-1, 0):  # up
            pts = [(cx, cy-hw), (cx-hw, cy+hw), (cx+hw, cy+hw)]
        else:
            ex = cx + dj*(CELL_SIZE//2 - 2)
            ey = cy + di*(CELL_SIZE//2 - 2)
            pygame.draw.line(self.screen, ARROW_COLOR, (cx, cy), (ex, ey), 3)
            pts = None
        if pts:
            pygame.draw.polygon(self.screen, ARROW_COLOR, pts)
        # draw step info
        base_y = self.H * CELL_SIZE + 5
        info = f"Step {idx}/{len(self.history)-1}  Pos:{state['pos']}  Dir:{state['direc']}"
        text_surf = self.font.render(info, True, (0,0,0))
        self.screen.blit(text_surf, (5, base_y))
        # draw island stacks, each on its own line
        for k in range(self.num_islands):
            stack_line = f"Island {k}: {state['stacks'][k]}"
            y = base_y + (k+1)*(FONT_SIZE + 4)
            self.screen.blit(self.font.render(stack_line, True, (0,0,0)), (5, y))
